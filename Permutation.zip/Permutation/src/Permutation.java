import java.util.ArrayList;
import java.util.List;

public class Permutation {

	private List<String> result = new ArrayList<String>();

	public Permutation(int number) {
		List<Integer> sequence = new ArrayList<Integer>();

		for (int i = 1; i <= number; i++) {
			sequence.add(i);
		}

		permute(new ArrayList<Integer>(), sequence);
		printResult();
	}

	public void permute(List<Integer> permutation, List<Integer> sequence) {
		if (sequence.size() == 0) {
			result.add(integerListToString(permutation));
		} else {
			for (int i = 0; i < sequence.size(); i++) {
				List<Integer> newPermutation = new ArrayList<Integer>(permutation);
				newPermutation.add(sequence.get(i));

				List<Integer> newSequence = new ArrayList<Integer>(sequence);
				newSequence.remove(i);

				permute(newPermutation, newSequence);
			}
		}
	}

	public void printResult() {
		for (String string : result) {
			System.out.println(string);
		}
	}

	public String integerListToString(List<Integer> list) {
		String str = "";

		for (Integer integer : list)
			str += Integer.toString(integer);

		return str;
	}

	public static void main(String[] args) {
		new Permutation(3);
	}
}
