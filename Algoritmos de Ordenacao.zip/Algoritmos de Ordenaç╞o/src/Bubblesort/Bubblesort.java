package Bubblesort;

import java.util.Scanner;

public class Bubblesort {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);   
	    
	    	int vetor[] = {12, 2, 18, 23, 1, 3};
	        int temp;
	        int contador = 1;
	        do{
	            for (int i=0; i < vetor.length -1; i++){
	                if (vetor[i] > vetor [i+1]){
	                    temp = vetor[i];
	                    vetor[i] = vetor[i+1];
	                    vetor[i+1] = temp;
	                }
	            }
	            contador++;
	        } while (contador < vetor.length);
	        String numerosOrdenados = "";
	        for (int n : vetor) {
	            numerosOrdenados += n+" ";
	        }
	        System.out.print(numerosOrdenados);
	    }
	}

