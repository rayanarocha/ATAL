package Selectionsort;

import java.util.Scanner;

public class Selectionsort {

	public int n = 0;
	
	public Selectionsort(int n) {
		this.n = n;
	}
	
	public int getN() {
		return n;
	}

	public void setN(int n) {
		this.n = n;
	}

	void selectionsort(int vet[]) {
	    int i, j, min, aux;
	 
	    for(i = 0; i < n; i++) {
	        min = i;
	        for(j = i + 1; j < n; j++) {
	            if(vet[j] < vet[min])
	                min = j;
	            aux = vet[min];
	            vet[min] = vet[i];
	            vet[i] = aux;
	        }
	    }
}

	 
public static void main(String[] args) {
		
	Scanner teclado = new Scanner(System.in);
		
		System.out.println("Digite N: ");
		int n = teclado.nextInt();
		
		int i, vet[n];
		
		Selectionsort select = new Selectionsort(n);
		
		for(i = 0; i < n; i++)
	        System.out.println(vet[i]);
	    select.selectionsort(vet);
	    System.out.println("\n");
	    for(i = 0; i < n; i++)
	        System.out.println(vet[i]);
	    System.out.println("\n");
	    //return 0;

	}
}

	    
		
