import java.util.Scanner;
public class Main {
    
    public static void main(String[] args) {
    	
    	Subconjuntos sub = new Subconjuntos();
    	
        Scanner keyboard = new Scanner(System.in);
        //n--> n�mero de elementos
        System.out.print("Insira o n� de elementos do conjunto: ");
        int n = keyboard.nextInt();
        int[] X = new int[n];
        System.out.println("Insira os valores do conjunto: ");
        for (int i = 0; i < X.length; i++) {
            System.out.print((i + 1) + "� Elemento ");
            X[i] = keyboard.nextInt();
        }
        
        sub.subconjuntos(X);
    }
}
